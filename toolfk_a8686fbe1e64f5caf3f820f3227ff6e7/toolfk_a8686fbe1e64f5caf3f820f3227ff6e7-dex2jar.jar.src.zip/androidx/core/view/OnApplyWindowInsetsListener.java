package androidx.core.view;

import android.view.View;

public interface OnApplyWindowInsetsListener {
  WindowInsetsCompat onApplyWindowInsets(View paramView, WindowInsetsCompat paramWindowInsetsCompat);
}


/* Location:              C:\Users\Root1\Desktop\Stash\output\!\toolfk_a8686fbe1e64f5caf3f820f3227ff6e7\toolfk_a8686fbe1e64f5caf3f820f3227ff6e7-dex2jar.jar!\androidx\core\view\OnApplyWindowInsetsListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */