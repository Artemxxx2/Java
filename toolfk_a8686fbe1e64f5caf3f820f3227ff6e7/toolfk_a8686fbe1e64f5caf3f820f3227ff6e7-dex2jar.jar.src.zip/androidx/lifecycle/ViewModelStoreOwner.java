package androidx.lifecycle;

import androidx.annotation.NonNull;

public interface ViewModelStoreOwner {
  @NonNull
  ViewModelStore getViewModelStore();
}


/* Location:              C:\Users\Root1\Desktop\Stash\output\!\toolfk_a8686fbe1e64f5caf3f820f3227ff6e7\toolfk_a8686fbe1e64f5caf3f820f3227ff6e7-dex2jar.jar!\androidx\lifecycle\ViewModelStoreOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */