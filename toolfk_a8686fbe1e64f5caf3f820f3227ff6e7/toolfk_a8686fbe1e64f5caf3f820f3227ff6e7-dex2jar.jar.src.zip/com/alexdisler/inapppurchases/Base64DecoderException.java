package com.alexdisler.inapppurchases;

public class Base64DecoderException extends Exception {
  private static final long serialVersionUID = 1L;
  
  public Base64DecoderException() {}
  
  public Base64DecoderException(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\Users\Root1\Desktop\Stash\output\!\toolfk_a8686fbe1e64f5caf3f820f3227ff6e7\toolfk_a8686fbe1e64f5caf3f820f3227ff6e7-dex2jar.jar!\com\alexdisler\inapppurchases\Base64DecoderException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */