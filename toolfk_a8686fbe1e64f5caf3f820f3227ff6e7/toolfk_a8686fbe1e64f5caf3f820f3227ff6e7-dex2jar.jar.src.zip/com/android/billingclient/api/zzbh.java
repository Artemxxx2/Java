package com.android.billingclient.api;

import androidx.annotation.Nullable;
import java.util.List;

public final class zzbh {
  @Nullable
  private final List zza;
  
  private final BillingResult zzb;
  
  public zzbh(BillingResult paramBillingResult, @Nullable List paramList) {
    this.zza = paramList;
    this.zzb = paramBillingResult;
  }
  
  public final BillingResult zza() {
    return this.zzb;
  }
  
  @Nullable
  public final List zzb() {
    return this.zza;
  }
}


/* Location:              C:\Users\Root1\Desktop\Stash\output\!\toolfk_a8686fbe1e64f5caf3f820f3227ff6e7\toolfk_a8686fbe1e64f5caf3f820f3227ff6e7-dex2jar.jar!\com\android\billingclient\api\zzbh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */