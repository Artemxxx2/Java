package com.android.billingclient.api;

import androidx.annotation.Nullable;
import java.util.List;

final class zzas {
  private final List zza;
  
  private final BillingResult zzb;
  
  zzas(BillingResult paramBillingResult, @Nullable List paramList) {
    this.zza = paramList;
    this.zzb = paramBillingResult;
  }
  
  final BillingResult zza() {
    return this.zzb;
  }
  
  final List zzb() {
    return this.zza;
  }
}


/* Location:              C:\Users\Root1\Desktop\Stash\output\!\toolfk_a8686fbe1e64f5caf3f820f3227ff6e7\toolfk_a8686fbe1e64f5caf3f820f3227ff6e7-dex2jar.jar!\com\android\billingclient\api\zzas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */